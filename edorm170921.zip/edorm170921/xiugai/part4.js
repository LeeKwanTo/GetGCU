document.getElementById("bgword1").style.display="";//none为隐藏
document.all.word1.innerHTML="昨天下午一位管院的17级新生丢了饭卡，距离领饭卡不到半天，这个掉饭卡的记录一直被打破,下次超越不知道又是什么时候。"//文字1
document.all.wfrom1.innerHTML="来自群聊"//文字来源1

document.getElementById("bgpic1").style.display="none";//none为隐藏
document.all.pfrom1.innerHTML="来自群聊"//图片来源1


document.getElementById("bgword2").style.display="none";//none为隐藏
document.all.word2.innerHTML=""//文字2
document.all.wfrom2.innerHTML="来自群聊或者朋友圈"//文字来源2

document.getElementById("bgpic2").style.display="none";//none为隐藏
document.all.pfrom2.innerHTML="来自群聊"//图片来源2


document.getElementById("bgword3").style.display="none";//none为隐藏
document.all.word3.innerHTML=""//文字3
document.all.wfrom3.innerHTML="来自群聊或者朋友圈"//文字来源3

document.getElementById("bgpic3").style.display="none";//none为隐藏
document.all.pfrom3.innerHTML="来自群聊"//图片来源3


document.getElementById("bgword4").style.display="none";//none为隐藏
document.all.word4.innerHTML=""//文字4
document.all.wfrom4.innerHTML="来自群聊或者朋友圈"//文字来源4

document.getElementById("bgpic4").style.display="none";//none为隐藏
document.all.pfrom4.innerHTML="来自群聊"//图片来源4


document.getElementById("bgword5").style.display="none";//none为隐藏
document.all.word5.innerHTML=""//文字2
document.all.wfrom5.innerHTML="来自群聊或者朋友圈"//文字来源5

document.getElementById("bgpic5").style.display="none";//none为隐藏
document.all.pfrom5.innerHTML="来自群聊"//图片来源5