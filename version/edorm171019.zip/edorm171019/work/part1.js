
//  --  Part 1  --


// 01 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("m01").style.display="";//none隐藏
document.all.title01.innerHTML="秋风有凉意 秋台未停歇"//标题
document.all.fr01.innerHTML="花都天气"//来源
function L01(){
window.open("https://mp.weixin.qq.com/s/fpv8_lfZkL0SJdidjJQ_vA"//链接
);}


// 02 - 图文  ∷∷∷ ▇▇
//
document.getElementById("m02").style.display="";//none隐藏
document.all.title02.innerHTML="忽如一夜秋风来，京东福利走起来"//标题
document.all.fr02.innerHTML="华广校园生态"//来源
function L02(){
window.open("http://mp.weixin.qq.com/s/NJoWOoTgqRtmcPhE7cq4-Q"//链接
);}


// 03 - 大图   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓
document.getElementById("m03").style.display="";//none隐藏
document.all.title03.innerHTML="经院活动 | 荷兰之夜欢迎晚会预告"//标题
function L03(){
window.open("http://mp.weixin.qq.com/s/us_tK1aj0sDQ2aPF0FWgPA"//链接
);}


// 04 - 视频   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓
document.getElementById("m04").style.display="none";//none隐藏
document.all.title04.innerHTML="2017华南理工大学广州学院军训汇演"//标题
document.all.time04.innerHTML="25：33"//时长
function L04(){
window.open("http://mudu.tv/watch/1273610?referVisitorId=1506927641man19962rk"//链接
);}


// 05 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("m05").style.display="none";//none隐藏
document.all.title05.innerHTML="花都区秀全街道招募入户大走访活动实习生的公告"//标题
document.all.fr05.innerHTML="华广就业指导中心"//来源
function L05(){
window.open("http://mp.weixin.qq.com/s/AeXuzMxR5VswzYFmv6axDg"//链接
);}


// 06 - - 已删


// 07 - 3图图文   ███   ███  ███
//               071   072  073
document.getElementById("m07").style.display="none";//none隐藏
document.all.title07.innerHTML="华广迎新晚会，你不容错过的年度视听盛宴"//标题
document.all.fr07.innerHTML="华广小助手"//来源
function L07(){
window.open("http://mp.weixin.qq.com/s/t6AGwhVx93sDlm-yXYcE8w"//链接
);}


// 08 - 通知 ▽
// 
document.getElementById("m08").style.display="none";//none隐藏
document.all.title08.innerHTML="国庆放假安全检查及后勤工作安排"//标题
document.all.fr08.innerHTML="后勤处"//来源
document.all.detail08.innerHTML=
"放假期间学校将实行封闭式管理<br>学校大门岗将对进出校门的人员、车辆进行登记，从 9月 30日 18时起 至 10月 8日 12时 大门两侧小门将关闭，人员、车辆一律从校大门进出；从 9月 30日起 至 10月 8日 行政楼二楼大门关闭，所有人员一律从一楼进出。<br>学校各食堂及餐厅于 10月 1日 至 10月 7日 放假， 10月 8日 正常营业。放假期间第一食堂、第三食堂一楼和第四食堂一楼正常营业。<br>学校医务所值班安排<br>学校医务所国庆放假期间（ 10月 1日 — 10月 8日 ）24小时有人值班，平诊时间8:40—12:00,2:40—17:30，其余时间为急诊时间，10月 9日 恢复正常。<br>若国庆期间，存在安全等方面的问题，请及时联系学校后勤处保卫科，联系电话：36903186。"//通知内容
//function L08(){window.open("");}
document.getElementById("m08img").style.display="none";//none不显示图片