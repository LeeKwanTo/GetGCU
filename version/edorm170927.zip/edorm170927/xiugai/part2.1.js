//---最新资讯1
document.getElementById("new1").style.display="none";//none隐藏

document.all.new1title.innerHTML="华广专场| #广东文都教育2019考研系列讲座之早知道#"//标题
document.all.new1detail.innerHTML="9月7日 19:00 A3-110"//描述
document.all.new1from.innerHTML="华广人力资源学研会"//来源
function new1Link(){
window.open("http://mp.weixin.qq.com/s/KaafLndp8Klro1yhfrmW6w"//链接
);}
document.getElementById("new1gz").style.display="none";//不能盖章none





//---最新资讯2
document.getElementById("new2").style.display="";//none隐藏

document.all.new2title.innerHTML="招聘信息 | 华广-建行金蜜蜂校园E银行招聘啦！"//标题
document.all.new2detail.innerHTML="9月13日截止报名"//描述
document.all.new2from.innerHTML="华广管院学生就业创业促进会"//来源
function new2Link(){
window.open("http://mp.weixin.qq.com/s/MeToRptKk_iGAm_iv97S-Q"//链接
);}
document.getElementById("new2gz").style.display="none";//不能盖章none





//---最新资讯3
document.getElementById("new3").style.display="none";//none隐藏

document.all.new3title.innerHTML="知识视界答题比赛"//标题
document.all.new3detail.innerHTML="活动时间：9月20日-10月30日"//描述
document.all.new3from.innerHTML="华广图书馆"//来源
function new3Link(){
window.open("http://mp.weixin.qq.com/s/VpfVOfIVo07xrN5ko7CI0w"//链接
);}
document.getElementById("new3gz").style.display="none";//不能盖章none





//---最新资讯4
document.getElementById("new4").style.display="";//none隐藏

document.all.new4title.innerHTML="图书馆新生“书山寻宝”入馆教育活动"//标题
document.all.new4detail.innerHTML="活动时间：9月8日-10日"//描述
document.all.new4from.innerHTML="华广图书馆"//来源
function new4Link(){
window.open("http://mp.weixin.qq.com/s/NkX-42gqcGCXjS33i7C-pA"//链接
);}
document.getElementById("new4gz").style.display="none";//不能盖章none





//---最新资讯5
document.getElementById("new5").style.display="none";//none隐藏
document.all.new5title.innerHTML="开学第一战丨听说你要陪我上山看球哟！"//标题
document.all.new5detail.innerHTML="报名截止时间：9月8日12：00 <br>活动时间：9月16日19：35<br>活动地点：越秀山体育场"//描述
document.all.new5from.innerHTML="华广足协"//来源
function new5Link(){
window.open("http://mp.weixin.qq.com/s/PXbyzKr0TDzSU_i4dVN6kA"//链接
);}
document.getElementById("new5gz").style.display="none";//不能盖章none





//---最新资讯6
document.getElementById("new6").style.display="none";//none隐藏

document.all.new6title.innerHTML="我是标题"//标题
document.all.new6detail.innerHTML="这是描述"//描述
document.all.new6from.innerHTML="公众号名称"//来源
function new6Link(){
window.open("这是链接"//链接
);}
document.getElementById("new6gz").style.display="none";//不能盖章none

