//---模块08已删除



//---模块09---视频---图片09.jpg
document.getElementById("id09").style.display="none";//none为隐藏
document.all.title09.innerHTML="全心全艺只为·你"//标题
document.all.time09.innerHTML="1:57"//时长
function Link09(){
window.open("https://v.qq.com/x/page/p0549gjy94m.html"//链接
);}


//---模块10---图文---图片10.jpg
document.getElementById("id10").style.display="none";//none为隐藏
document.all.title10.innerHTML="华广表白墙第十五期"//标题
document.all.from10.innerHTML="纵梦华广"//来源
function Link10(){
window.open("http://mp.weixin.qq.com/s/nxqrSZE67e15AeV18eQhNg"//链接
);}


//---模块11---图文---图片11.jpg
document.getElementById("id11").style.display="none";//none为隐藏
document.all.title11.innerHTML="【权益动态】新生特辑——上"//标题
document.all.from11.innerHTML="华广学生会"//来源
function Link11(){
window.open("http://mp.weixin.qq.com/s/tAaAxFAsjAH_Diyoo0SBog"//链接
);}



//---模块12---3图图文---图片121.jpg 122.jpg 123.jpg
document.getElementById("id12").style.display="none";//none为隐藏
document.all.title12.innerHTML="很高兴认识你，我是华广新生录取通知书！"//标题
document.all.from12.innerHTML="华工广州学院招生办"//来源
function Link12(){
window.open("http://mp.weixin.qq.com/s/JcQxvalBBYYe4cIIzVBddA"//链接
);}



//---模块13---大图广告---图片13.jpg
document.getElementById("id13").style.display="";//none为隐藏
document.all.title13.innerHTML="省级荣誉证书！10万现金大奖！全城寻找2017展翅计划首席实习生！"//标题
function Link13(){
window.open("http://mp.weixin.qq.com/s/3N6N1DZm5uhSumuePB6VKQ"//链接
);}



//---模块14---通知---图片14.jpg
document.getElementById("id14").style.display="";//none隐藏
document.all.title14.innerHTML="停水通知"//标题
document.all.from14.innerHTML="华南理工大学广州学院后勤处"//来源
document.all.detail14.innerHTML=
"接花都区自来水公司通知，2017年9月23日上午7:00至24日上午7:00对花都大道供水管道实施停水并网接驳，届时花都区中心城区水压普遍偏低可能影响我校自来水正常供应。望大家提前做好储水工作。"//通知内容
function Link14(){
window.open(""//链接
);}
document.getElementById("id14img").style.display="none";//none不显示图片


//---模块15---图文---图片15.jpg
document.getElementById("id15").style.display="";//none为隐藏
document.all.title15.innerHTML="这五大专业最难就业！2017年大学生就业报告出炉！"//标题
document.all.from15.innerHTML="广东学联"//来源
function Link15(){
window.open("https://mp.weixin.qq.com/s/Hvhc-ZFjCKZNQmj9MjLYvQ"//链接
);}



//---模块16（表白墙专用）---图文---图片16.jpg
document.getElementById("id16").style.display="";//none为隐藏
document.all.title16.innerHTML="华广表白墙第十八期"//标题
document.all.from16.innerHTML="纵梦华广"//来源
function Link16(){
window.open("http://mp.weixin.qq.com/s/IIkIpm9W6cj3TyJs-_TQfg"//链接
);}



//---模块17---大图广告---图片17.jpg
document.getElementById("id17").style.display="none";//none为隐藏
document.all.title17.innerHTML="社联赐你组织面试pass卡"//标题
function Link17(){
window.open("http://mp.weixin.qq.com/s/CjjF9kuMjs2DDCKdtIqB7w"//链接
);}