//---模块08---图文---图片08.jpg
document.getElementById("id08").style.display="none";//none为隐藏
document.all.title08.innerHTML="我是标题"//标题
document.all.from08.innerHTML="公众号名称"//来源
function Link08(){
window.open("这是链接"//链接
);}


//---模块09---视频---图片09.jpg
document.getElementById("id09").style.display="";//none为隐藏
document.all.title09.innerHTML="华广微电影 回首"//标题
document.all.time09.innerHTML="9∶40"//时长
function Link09(){
window.open("https://v.qq.com/x/page/u050939p22d.html"//链接
);}


//---模块10---图文---图片10.jpg
document.getElementById("id10").style.display="";//none为隐藏
document.all.title10.innerHTML="你有想过上大学的意义吗？"//标题
document.all.from10.innerHTML="三人行"//来源
function Link10(){
window.open("http://mp.weixin.qq.com/s/nuPdIUDkh2xwmFs9aAO5nw"//链接
);}


//---模块11---图文---图片08.jpg
document.getElementById("id11").style.display="none";//none为隐藏
document.all.title11.innerHTML="我是标题"//标题
document.all.from11.innerHTML="公众号名称"//来源
function Link11(){
window.open("这是链接"//链接
);}



//---模块12---3图图文---图片121.jpg 122.jpg 123.jpg
document.getElementById("id12").style.display="none";//none为隐藏
document.all.title12.innerHTML="很高兴认识你，我是华广新生录取通知书！"//标题
document.all.from12.innerHTML="华工广州学院招生办"//来源
function Link12(){
window.open("http://mp.weixin.qq.com/s/JcQxvalBBYYe4cIIzVBddA"//链接
);}



//---模块13---大图广告---图片13.jpg
document.getElementById("id13").style.display="none";//none为隐藏
document.all.title13.innerHTML="这是标题"//标题
function Link13(){
window.open("这是链接"//链接
);}



//---模块14---通知---图片14.jpg
document.getElementById("id14").style.display="none";//none隐藏
document.all.title14.innerHTML="后勤处放假通知"//标题
document.all.from14.innerHTML="后勤处"//时长
document.all.detail14.innerHTML=
"这是通知内容<br>这是通知内容第二行"//通知内容
function Link14(){
window.open(" "//链接
);}
document.getElementById("id14img").style.display="none";//none不显示图片


//---模块15---图文---图片15.jpg
document.getElementById("id15").style.display="";//none为隐藏
document.all.title15.innerHTML="2017级迎新晚会节目征集"//标题
document.all.from15.innerHTML="华广学生艺术团"//来源
function Link15(){
window.open("http://mp.weixin.qq.com/s/6hXVyfmNP_EJinjuU3kQcA"//链接
);}



//---模块16---图文---图片16.jpg
document.getElementById("id16").style.display="";//none为隐藏
document.all.title16.innerHTML="两分钟教你剪出科幻大片"//标题
document.all.from16.innerHTML="华广创意人"//来源
function Link16(){
window.open("http://mp.weixin.qq.com/s/JNGlEcx7HpQtHQdhFNK8kA"//链接
);}



//---模块17---大图广告---图片17.jpg
document.getElementById("id17").style.display="none";//none为隐藏
document.all.title17.innerHTML="这是标题"//标题
function Link17(){
window.open("这是链接"//链接
);}