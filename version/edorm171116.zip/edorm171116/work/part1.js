
//  --  Part 1  --


// 01 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("m01").style.display="";//none隐藏
document.all.title01.innerHTML="权益动态 | 前方高能：蛇出没！"//标题
document.all.fr01.innerHTML="华工广州学院经济学院团委学生会"//来源
function L01(){
window.open("http://mp.weixin.qq.com/s/lUgWbTm30Os29rBZE_ahLA"//链接
);}


// 02 - 图文  ∷∷∷ ▇▇
//
document.getElementById("m02").style.display="";//none隐藏
document.all.title02.innerHTML="户外社校运会要去的武功山有多美？"//标题
document.all.fr02.innerHTML="华广鹿影户外社"//来源
function L02(){
window.open("http://mp.weixin.qq.com/s/JPFLdiDV7QN2N9BYh99t2Q"//链接
);}


// 03 - 大图   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓
document.getElementById("m03").style.display="none";//none隐藏
document.all.title03.innerHTML=""//标题
function L03(){
window.open(""//链接
);}


// 04 - 视频   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓   视频推文如果是微信推文里的，填http://edorm.yowoit.com/work/shipin1.html
document.getElementById("m04").style.display="";//none隐藏
document.all.title04.innerHTML="【权益视角】吃或轻于鸿毛，安才重于泰山！"//标题
document.all.time04.innerHTML="4：13"//时长
function L04(){
window.open("http://edorm.yowoit.com/work/shipin1.html"//链接
);}



// 05 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("m05").style.display="";//none隐藏
document.all.title05.innerHTML="上时外卖，有缘再见！"//标题
document.all.fr05.innerHTML="上时华广"//来源
function L05(){
window.open("http://mp.weixin.qq.com/s/GYOvir1JYIUGyDtpFNA6fg"//链接
);}


// 06 - - 已删


// 07 - 3图图文   ███   ███  ███
//               071   072  073
document.getElementById("m07").style.display="";//none隐藏
document.all.title07.innerHTML="华广街拍 | 再忙也要停下来看看风景呀"//标题
document.all.fr07.innerHTML="华广小助手"//来源
function L07(){
window.open("http://mp.weixin.qq.com/s/ZAeqshLesRDuYRp2xF9X2Q"//链接
);}


// 08 - 通知 ▽
// 
document.getElementById("m08").style.display="none";//none隐藏
document.all.title08.innerHTML="易舍群起禁止发布微信辅助兼职信息"//标题
document.all.fr08.innerHTML="这届易舍群管"//来源
document.all.detail08.innerHTML=
"为营造清朗的华广网络环境，抵制黄赌毒等不法行为，易舍即日起对易舍群禁止发布微信辅助兼职，包括写在群昵称，一旦发现立即移除"//通知内容
//function L08(){window.open("");}
document.getElementById("m08img").style.display="none";//none不显示图片