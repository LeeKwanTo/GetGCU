
// 控制二维码弹出与隐藏
$(document).ready(function(){
$("#close1-1").click(function(){$("#AD1").css({'display':'none'})});
$("#close1-2").click(function(){$("#AD1").css({'display':'none'})});
$("#open1").click(function(){$("#AD1").css({'display':'block'})});

$("#close2-1").click(function(){$("#AD2").css({'display':'none'})});
$("#close2-2").click(function(){$("#AD2").css({'display':'none'})});
$("#open2").click(function(){$("#AD2").css({'display':'block'})});

$("#close3-1").click(function(){$("#AD3").css({'display':'none'})});
$("#close3-2").click(function(){$("#AD3").css({'display':'none'})});
$("#open3").click(function(){$("#AD3").css({'display':'block'})});

$("#close4-1").click(function(){$("#AD4").css({'display':'none'})});
$("#close4-2").click(function(){$("#AD4").css({'display':'none'})});
$("#open4").click(function(){$("#AD4").css({'display':'block'})});

$("#close5-1").click(function(){$("#AD5").css({'display':'none'})});
$("#close5-2").click(function(){$("#AD5").css({'display':'none'})});
$("#open5").click(function(){$("#AD5").css({'display':'block'})});

$("#close6-1").click(function(){$("#AD6").css({'display':'none'})});
$("#close6-2").click(function(){$("#AD6").css({'display':'none'})});
$("#open6").click(function(){$("#AD6").css({'display':'block'})});

$("#close7-1").click(function(){$("#AD7").css({'display':'none'})});
$("#close7-2").click(function(){$("#AD7").css({'display':'none'})});
$("#open7").click(function(){$("#AD7").css({'display':'block'})});

$("#close8-1").click(function(){$("#AD8").css({'display':'none'})});
$("#close8-2").click(function(){$("#AD8").css({'display':'none'})});
$("#open8").click(function(){$("#AD8").css({'display':'block'})});

$("#close9-1").click(function(){$("#AD9").css({'display':'none'})});
$("#close9-2").click(function(){$("#AD9").css({'display':'none'})});
$("#open9").click(function(){$("#AD9").css({'display':'block'})});

$("#close10-1").click(function(){$("#AD10").css({'display':'none'})});
$("#close10-2").click(function(){$("#AD10").css({'display':'none'})});
$("#open10").click(function(){$("#AD10").css({'display':'block'})});

$("#close11-1").click(function(){$("#AD11").css({'display':'none'})});
$("#close11-2").click(function(){$("#AD11").css({'display':'none'})});
$("#open11").click(function(){$("#AD11").css({'display':'block'})});

$("#close12-1").click(function(){$("#AD12").css({'display':'none'})});
$("#close12-2").click(function(){$("#AD12").css({'display':'none'})});
$("#open12").click(function(){$("#AD12").css({'display':'block'})});

$("#close13-1").click(function(){$("#AD13").css({'display':'none'})});
$("#close13-2").click(function(){$("#AD13").css({'display':'none'})});
$("#open13").click(function(){$("#AD13").css({'display':'block'})});

$("#close14-1").click(function(){$("#AD14").css({'display':'none'})});
$("#close14-2").click(function(){$("#AD14").css({'display':'none'})});
$("#open14").click(function(){$("#AD14").css({'display':'block'})});

$("#close15-1").click(function(){$("#AD15").css({'display':'none'})});
$("#close15-2").click(function(){$("#AD15").css({'display':'none'})});
$("#open15").click(function(){$("#AD15").css({'display':'block'})});

$("#close16-1").click(function(){$("#AD16").css({'display':'none'})});
$("#close16-2").click(function(){$("#AD16").css({'display':'none'})});
$("#open16").click(function(){$("#AD16").css({'display':'block'})});

$("#close17-1").click(function(){$("#AD17").css({'display':'none'})});
$("#close17-2").click(function(){$("#AD17").css({'display':'none'})});
$("#open17").click(function(){$("#AD17").css({'display':'block'})});

$("#close18-1").click(function(){$("#AD18").css({'display':'none'})});
$("#close18-2").click(function(){$("#AD18").css({'display':'none'})});
$("#open18").click(function(){$("#AD18").css({'display':'block'})});

$("#close19-1").click(function(){$("#AD19").css({'display':'none'})});
$("#close19-2").click(function(){$("#AD19").css({'display':'none'})});
$("#open19").click(function(){$("#AD19").css({'display':'block'})});

$("#close20-1").click(function(){$("#AD20").css({'display':'none'})});
$("#close20-2").click(function(){$("#AD20").css({'display':'none'})});
$("#open20").click(function(){$("#AD20").css({'display':'block'})});

$("#close21-1").click(function(){$("#AD21").css({'display':'none'})});
$("#close21-2").click(function(){$("#AD21").css({'display':'none'})});
$("#open21").click(function(){$("#AD21").css({'display':'block'})});

$("#close22-1").click(function(){$("#AD22").css({'display':'none'})});
$("#close22-2").click(function(){$("#AD22").css({'display':'none'})});
$("#open22").click(function(){$("#AD22").css({'display':'block'})});

$("#close23-1").click(function(){$("#AD23").css({'display':'none'})});
$("#close23-2").click(function(){$("#AD23").css({'display':'none'})});
$("#open23").click(function(){$("#AD23").css({'display':'block'})});

$("#close24-1").click(function(){$("#AD24").css({'display':'none'})});
$("#close24-2").click(function(){$("#AD24").css({'display':'none'})});
$("#open24").click(function(){$("#AD24").css({'display':'block'})});

$("#close25-1").click(function(){$("#AD25").css({'display':'none'})});
$("#close25-2").click(function(){$("#AD25").css({'display':'none'})});
$("#open25").click(function(){$("#AD25").css({'display':'block'})});

$("#close26-1").click(function(){$("#AD26").css({'display':'none'})});
$("#close26-2").click(function(){$("#AD26").css({'display':'none'})});
$("#open26").click(function(){$("#AD26").css({'display':'block'})});

$("#close27-1").click(function(){$("#AD27").css({'display':'none'})});
$("#close27-2").click(function(){$("#AD27").css({'display':'none'})});
$("#open27").click(function(){$("#AD27").css({'display':'block'})});

$("#close28-1").click(function(){$("#AD28").css({'display':'none'})});
$("#close28-2").click(function(){$("#AD28").css({'display':'none'})});
$("#open28").click(function(){$("#AD28").css({'display':'block'})});

$("#close29-1").click(function(){$("#AD29").css({'display':'none'})});
$("#close29-2").click(function(){$("#AD29").css({'display':'none'})});
$("#open29").click(function(){$("#AD29").css({'display':'block'})});

$("#close30-1").click(function(){$("#AD30").css({'display':'none'})});
$("#close30-2").click(function(){$("#AD30").css({'display':'none'})});
$("#open30").click(function(){$("#AD30").css({'display':'block'})})
});