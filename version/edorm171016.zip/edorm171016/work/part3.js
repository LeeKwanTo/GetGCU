
//  --  Part 3  --


// 09 - 视频   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓
document.getElementById("m09").style.display="";//none隐藏
document.all.title09.innerHTML="2分钟延时视频看完华广2017新生军训汇演"//标题
document.all.time09.innerHTML="2:16"//时长
function L09(){
window.open("https://v.qq.com/x/page/m0556xha2jg.html"//链接
);}


// 10 - 大图   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓
document.getElementById("m10").style.display="";//none隐藏
document.all.title10.innerHTML="摄影｜斑斓梦境，黑白人生"//标题
function L10(){
window.open("http://mp.weixin.qq.com/s/HiGa3lnJms-gVDEI-zyveA"//链接
);}


// 11 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("m11").style.display="";//none隐藏
document.all.title11.innerHTML="自我介绍的精髓：让面试官在一分钟内记住你！"//标题
document.all.fr11.innerHTML="华广就业指导中心"//来源
function L11(){
window.open("http://mp.weixin.qq.com/s/tJh71TVGzvx6WujB8T2EwA"//链接
);}



// 12 - 3图图文   ███   ███  ███
//               121   122  123
document.getElementById("m12").style.display="";//none隐藏
document.all.title12.innerHTML="告别军训 | 不过13天却是波及一生的回忆"//标题
document.all.fr12.innerHTML="华管人"//来源
function L12(){
window.open("http://mp.weixin.qq.com/s/r7Q9EYogPXZ1opQ6TDRr7A"//链接
);}


// 13 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("m13").style.display="";//none隐藏
document.all.title13.innerHTML="【权益动态】广州地铁要物检"//标题
document.all.fr13.innerHTML="华广学生会"//来源
function L13(){
window.open("http://mp.weixin.qq.com/s/lbkhyoynJN-muBKv38Fq_g"//链接
);}


// 14 - 通知 ▽
// 
document.getElementById("m14").style.display="";//none隐藏
document.all.title14.innerHTML="国庆放假安全检查及后勤工作安排"//标题
document.all.fr14.innerHTML="后勤处"//来源
document.all.detail14.innerHTML=
"学校各食堂及餐厅于 10月 1日 至 10月 7日 放假， 10月 8日 正常营业。为方便放假期间在校人员就餐，放假期间第一食堂、第三食堂一楼和第四食堂一楼正常营业。"//通知内容
//function L14(){window.open("");}//链接
document.getElementById("m14img").style.display="none";//无图片none


// 15 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("m15").style.display="";//none隐藏
document.all.title15.innerHTML="华广双创周|杨博：以95后的视角去创业"//标题
document.all.fr15.innerHTML="华广晨曦文学社"//来源
function L15(){
window.open("http://mp.weixin.qq.com/s/Ho7JYG94UJMvKD7otorCMg"//链接
);}



// 16 - 图文（表白墙专用）
// 
document.getElementById("m16").style.display="";//none隐藏
document.all.title16.innerHTML="华广表白墙第二十六期"//标题
document.all.fr16.innerHTML="纵梦华广"//来源
function L16(){
window.open("http://mp.weixin.qq.com/s/zb5GSIh6f0hQty4T_Bzk9w"//链接
);}



// 17 - 大图   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓
document.getElementById("m17").style.display="";//none隐藏
document.all.title17.innerHTML="『吾优设计师之家资源库』开通试用"//标题
function L17(){
window.open("http://mp.weixin.qq.com/s/zJEkku-oWD4Ag4afnnV35A"//链接
);}