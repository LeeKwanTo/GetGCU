//---比赛1
document.getElementById("bs1").style.display="none";//none隐藏
document.all.bs1title.innerHTML="华广专场| #广东文都教育2019考研系列讲座之早知道#"//标题
document.all.bs1detail.innerHTML="9月7日 19:00 A3-110"//描述
document.all.bs1from.innerHTML="华广人力资源学研会"//来源
function bs1Link(){
window.open("http://mp.weixin.qq.com/s/KaafLndp8Klro1yhfrmW6w"//链接
);}
document.getElementById("bs1gz").style.display="none";//不能盖章none



//---比赛2
document.getElementById("bs2").style.display="";//none隐藏
document.all.bs2title.innerHTML="知识视界答题比赛"//标题
document.all.bs2detail.innerHTML="活动时间：9月20日-10月30日"//描述
document.all.bs2from.innerHTML="华广图书馆"//来源
function bs2Link(){
window.open("http://mp.weixin.qq.com/s/VpfVOfIVo07xrN5ko7CI0w"//链接
);}
document.getElementById("bs2gz").style.display="none";//不能盖章none



//---比赛3
document.getElementById("bs3").style.display="none";//none隐藏
document.all.bs3title.innerHTML="我是标题"//标题
document.all.bs3detail.innerHTML="这是描述"//描述
document.all.bs3from.innerHTML="公众号名称"//来源
function bs3Link(){
window.open("这是链接"//链接
);}
document.getElementById("bs3gz").style.display="none";//不能盖章none



//---比赛4
document.getElementById("bs4").style.display="none";//none隐藏
document.all.bs4title.innerHTML="我是标题"//标题
document.all.bs4detail.innerHTML="这是描述"//描述
document.all.bs4from.innerHTML="公众号名称"//来源
function jz4Link(){
window.open("这是链接"//链接
);}
document.getElementById("bs4gz").style.display="none";//不能盖章none



//---比赛5
document.getElementById("bs5").style.display="none";//none隐藏
document.all.bs5title.innerHTML="我是标题"//标题
document.all.bs5detail.innerHTML="这是描述"//描述
document.all.bs5from.innerHTML="公众号名称"//来源
function bs5Link(){
window.open("这是链接"//链接
);}
document.getElementById("bs5gz").style.display="none";//不能盖章none



//---比赛6
document.getElementById("bs6").style.display="none";//none隐藏
document.all.bs6title.innerHTML="我是标题"//标题
document.all.bs6detail.innerHTML="这是描述"//描述
document.all.bs6from.innerHTML="公众号名称"//来源
function bs6Link(){
window.open("这是链接"//链接
);}
document.getElementById("bs6gz").style.display="none";//不能盖章none