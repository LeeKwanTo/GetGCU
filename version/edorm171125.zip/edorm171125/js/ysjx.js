
// 控制二维码弹出与隐藏
$(document).ready(function(){
$("#close1-1").click(function(){$("#AD1").css({'display':'none'})});
$("#close1-2").click(function(){$("#AD1").css({'display':'none'})});
$("#open1").click(function(){$("#AD1").css({'display':'block'})});

$("#close2-1").click(function(){$("#AD2").css({'display':'none'})});
$("#close2-2").click(function(){$("#AD2").css({'display':'none'})});
$("#open2").click(function(){$("#AD2").css({'display':'block'})});

$("#close3-1").click(function(){$("#AD3").css({'display':'none'})});
$("#close3-2").click(function(){$("#AD3").css({'display':'none'})});
$("#open3").click(function(){$("#AD3").css({'display':'block'})});

$("#close4-1").click(function(){$("#AD4").css({'display':'none'})});
$("#close4-2").click(function(){$("#AD4").css({'display':'none'})});
$("#open4").click(function(){$("#AD4").css({'display':'block'})});

$("#close5-1").click(function(){$("#AD5").css({'display':'none'})});
$("#close5-2").click(function(){$("#AD5").css({'display':'none'})});
$("#open5").click(function(){$("#AD5").css({'display':'block'})});
});
