
//  --  Part 1  --


// 01 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("m01").style.display="";//none隐藏
document.all.title01.innerHTML="华广说丨我们和“她”有个约会"//标题
document.all.fr01.innerHTML="印象华广"//来源
function L01(){
window.open("http://mp.weixin.qq.com/s/MCMac61ALftEkavSZr8nDw"//链接
);}


// 02 - 图文  ∷∷∷ ▇▇
//
document.getElementById("m02").style.display="";//none隐藏
document.all.title02.innerHTML="学生意外保险理赔流程简化理赔手续"//标题
document.all.fr02.innerHTML="华工广州学院招生办"//来源
function L02(){
window.open("https://mp.weixin.qq.com/s/_LK8QmWsMA4mV5dkr76rAw"//链接
);}


// 03 - 大图   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓
document.getElementById("m03").style.display="none";//none隐藏
document.all.title03.innerHTML=""//标题
function L03(){
window.open(""//链接
);}


// 04 - 视频   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓   视频推文如果是微信推文里的，填work/shipin1.html
document.getElementById("m04").style.display="none";//none隐藏
document.all.title04.innerHTML="管院2017返校日宣传视频出炉"//标题
document.all.time04.innerHTML="4：30"//时长
function L04(){
window.open("work/shipin1.html"//链接
);}



// 05 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("m05").style.display="";//none隐藏
document.all.title05.innerHTML="管理学院11.19返校日议程"//标题
document.all.fr05.innerHTML="华广管院校友会"//来源
function L05(){
window.open("http://mp.weixin.qq.com/s/Q-ikSV2EKM2YKo2CPkmizw"//链接
);}


// 06 - - 已删


// 07 - 3图图文   ███   ███  ███
//               071   072  073
document.getElementById("m07").style.display="";//none隐藏
document.all.title07.innerHTML="华广街拍 | 闲暇之秋"//标题
document.all.fr07.innerHTML="华广小助手"//来源
function L07(){
window.open("http://mp.weixin.qq.com/s/3IGNW2m8_5dQC3vc1ePJaw"//链接
);}


// 08 - 通知 ▽
// 
document.getElementById("m08").style.display="none";//none隐藏
document.all.title08.innerHTML="华广的学生可以查分了"//标题
document.all.fr08.innerHTML=""//来源
document.all.detail08.innerHTML=
"参加2017年下半年全国计算机等级考试的华广校内考生，现可通过校园网登录http://10.1.1.45:5184/查询成绩。对成绩有疑问或需查卷的考生，请11月15日前到B5-302进行咨询和登记。因省考试院暂未提供查询成绩的网址，校外考生请于11月9日（周四）的15:00-17:00拨打电话36903082进行咨询。以上咨询方式只适用于报考本考点的考生。"//通知内容
//function L08(){window.open("");}
document.getElementById("m08img").style.display="none";//none不显示图片