
//  --  Part 3  --


// 09 - 视频   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓   视频推文如果是微信推文里的，填work/shipin3.html
document.getElementById("m09").style.display="none";//none隐藏
document.all.title09.innerHTML="院运会 | 你努力的样子，真好看"//标题
document.all.time09.innerHTML="00:46"//时长
function L09(){
window.open("work/shipin3.html"//链接
);}


// 10 - 大图   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓
document.getElementById("m10").style.display="";//none隐藏
document.all.title10.innerHTML="创业在华广丨你准备好了吗？"//标题
function L10(){
window.open("http://mp.weixin.qq.com/s/7l0KdXNXuxutEJrzN2Zakg"//链接
);}


// 11 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("m11").style.display="";//none隐藏
document.all.title11.innerHTML="关于近期的学寓的人口普查工作，有人冒充师兄师姐敲宿舍门"//标题
document.all.fr11.innerHTML="华广学生公寓社区服务委员会"//来源
function L11(){
window.open("http://mp.weixin.qq.com/s/UD26r9JQlQcMNqJ041bD3A"//链接
);}



// 12 - 3图图文   ███   ███  ███
//               121   122  123
document.getElementById("m12").style.display="none";//none隐藏
document.all.title12.innerHTML=""//标题
document.all.fr12.innerHTML=""//来源
function L12(){
window.open(""//链接
);}


// 13 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("m13").style.display="";//none隐藏
document.all.title13.innerHTML="2018年IEET专业认证启动，快看看有没有你的专业"//标题
document.all.fr13.innerHTML="华工广州学院教务处"//来源
function L13(){
window.open("http://mp.weixin.qq.com/s/CCfxxuXvL7lSTr22oW1HMg"//链接
);}


// 14 - 通知 ▽
// 
document.getElementById("m14").style.display="none";//none隐藏
document.all.title14.innerHTML=""//标题
document.all.fr14.innerHTML=""//来源
document.all.detail14.innerHTML=
" "//通知内容
//function L14(){window.open("");}//链接
document.getElementById("m14img").style.display="";//无图片none


// 15 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("m15").style.display="none";//none隐藏
document.all.title15.innerHTML="何弃疗 | 如何治愈假期综合症"//标题
document.all.fr15.innerHTML="华工广州学院招生办"//来源
function L15(){
window.open("http://mp.weixin.qq.com/s/zeZ3oCruDNVOC6YR_TTNuw"//链接
);}



// 16 - 图文（表白墙专用）
// 
document.getElementById("m16").style.display="none";//none隐藏
document.all.title16.innerHTML="华广表白墙第六十四期"//标题
document.all.fr16.innerHTML="纵梦华广"//来源
function L16(){
window.open("http://mp.weixin.qq.com/s/NcgUi7dy8S-YAzYZ_1G-aQ"//链接
);}



// 17 - 大图   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓
document.getElementById("m17").style.display="none";//none隐藏
document.all.title17.innerHTML=""//标题
function L17(){
window.open(""//链接
);}