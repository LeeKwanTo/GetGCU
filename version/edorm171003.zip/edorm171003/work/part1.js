
//  --  Part 1  --


// 01 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("id01").style.display="";//none隐藏
document.all.title01.innerHTML="国庆中秋双节放假期间断网通知"//标题
document.all.from01.innerHTML="华广校园网"//来源
function Link01(){
window.open("http://mp.weixin.qq.com/s/UZrGP8CU5vgMEN09ZFurFA"//链接
);}


// 02 - 图文  ∷∷∷ ▇▇
//
document.getElementById("id02").style.display="";//none隐藏
document.all.title02.innerHTML="“新宝杯”| 我与智能咖啡机之旅"//标题
document.all.from02.innerHTML="华广青春汇"//来源
function Link02(){
window.open("http://mp.weixin.qq.com/s/o0UMyOquU4q5S5uBU8d7Jw"//链接
);}


// 03 - 大图   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓
document.getElementById("id03").style.display="";//none隐藏
document.all.title03.innerHTML="军训特辑丨快来为萌新们疯狂打call！"//标题
function Link03(){
window.open("http://mp.weixin.qq.com/s/Uuy3apkGdGMT4HZwr0ytBA"//链接
);}


// 04 - 视频   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓
document.getElementById("id04").style.display="";//none隐藏
document.all.title04.innerHTML="2017华南理工大学广州学院军训汇演"//标题
document.all.time04.innerHTML="25：33"//时长
function Link04(){
window.open("http://mudu.tv/watch/1273610?referVisitorId=1506927641man19962rk"//链接
);}


// 05 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("id05").style.display="none";//none隐藏
document.all.title05.innerHTML="花都区秀全街道招募入户大走访活动实习生的公告"//标题
document.all.from05.innerHTML="华广就业指导中心"//来源
function Link05(){
window.open("http://mp.weixin.qq.com/s/AeXuzMxR5VswzYFmv6axDg"//链接
);}


// 06 - 图片欣赏 - 图 061 062 063
//    ▽
document.getElementById("id06").style.display="none";//none隐藏
document.all.title06.innerHTML="【图片欣赏】华广｜柔和几何"//标题
document.all.from06.innerHTML="HiSam"//来源
function Link06(){
window.open("http://mp.weixin.qq.com/s/t6AGwhVx93sDlm-yXYcE8w"//链接
);}


// 07 - 3图图文   ███   ███  ███
//               071   072  073
document.getElementById("id07").style.display="";//none隐藏
document.all.title07.innerHTML="华广迎新晚会，你不容错过的年度视听盛宴"//标题
document.all.from07.innerHTML="华广小助手"//来源
function Link07(){
window.open("http://mp.weixin.qq.com/s/t6AGwhVx93sDlm-yXYcE8w"//链接
);}


// 08 - 通知 ▽
// 
document.getElementById("id08").style.display="";//none隐藏
document.all.title08.innerHTML="国庆放假安全检查及后勤工作安排"//标题
document.all.from08.innerHTML="后勤处"//来源
document.all.detail08.innerHTML=
"学校各食堂及餐厅于 10月 1日 至 10月 7日 放假， 10月 8日 正常营业。为方便放假期间在校人员就餐，放假期间第一食堂、第三食堂一楼和第四食堂一楼正常营业。"//通知内容
//function Link08(){window.open("");}
document.getElementById("id08img").style.display="none";//none不显示图片