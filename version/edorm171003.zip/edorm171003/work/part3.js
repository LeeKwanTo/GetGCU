
//  --  Part 3  --


// 09 - 视频   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓
document.getElementById("id09").style.display="none";//none隐藏
document.all.title09.innerHTML="全心全艺只为·你"//标题
document.all.time09.innerHTML="1:57"//时长
function Link09(){
window.open("https://v.qq.com/x/page/p0549gjy94m.html"//链接
);}


// 10 - 大图   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓
document.getElementById("id10").style.display="";//none隐藏
document.all.title10.innerHTML="摄影｜斑斓梦境，黑白人生"//标题
function Link10(){
window.open("http://mp.weixin.qq.com/s/HiGa3lnJms-gVDEI-zyveA"//链接
);}


// 11 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("id11").style.display="";//none隐藏
document.all.title11.innerHTML="自我介绍的精髓：让面试官在一分钟内记住你！"//标题
document.all.from11.innerHTML="华广就业指导中心"//来源
function Link11(){
window.open("http://mp.weixin.qq.com/s/tJh71TVGzvx6WujB8T2EwA"//链接
);}



// 12 - 3图图文   ███   ███  ███
//               121   122  123
document.getElementById("id12").style.display="none";//none隐藏
document.all.title12.innerHTML="很高兴认识你，我是华广新生录取通知书！"//标题
document.all.from12.innerHTML="华工广州学院招生办"//来源
function Link12(){
window.open("http://mp.weixin.qq.com/s/JcQxvalBBYYe4cIIzVBddA"//链接
);}


// 13 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("id13").style.display="";//none隐藏
document.all.title13.innerHTML="【权益动态】广州地铁要物检"//标题
document.all.from13.innerHTML="华广学生会"//来源
function Link13(){
window.open("http://mp.weixin.qq.com/s/lbkhyoynJN-muBKv38Fq_g"//链接
);}


// 14 - 通知 ▽
// 
document.getElementById("id14").style.display="";//none隐藏
document.all.title14.innerHTML="国庆放假安全检查及后勤工作安排"//标题
document.all.from14.innerHTML="后勤处"//来源
document.all.detail14.innerHTML=
"学校各食堂及餐厅于 10月 1日 至 10月 7日 放假， 10月 8日 正常营业。为方便放假期间在校人员就餐，放假期间第一食堂、第三食堂一楼和第四食堂一楼正常营业。"//通知内容
//function Link14(){window.open("");}//链接
document.getElementById("id14img").style.display="none";//none不显示图片


// 15 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("id15").style.display="";//none隐藏
document.all.title15.innerHTML="华广双创周|杨博：以95后的视角去创业"//标题
document.all.from15.innerHTML="华广晨曦文学社"//来源
function Link15(){
window.open("http://mp.weixin.qq.com/s/Ho7JYG94UJMvKD7otorCMg"//链接
);}



// 16 - 图文（表白墙专用）
// 
document.getElementById("id16").style.display="";//none隐藏
document.all.title16.innerHTML="华广表白墙第二十六期"//标题
document.all.from16.innerHTML="纵梦华广"//来源
function Link16(){
window.open("http://mp.weixin.qq.com/s/zb5GSIh6f0hQty4T_Bzk9w"//链接
);}



// 17 - 大图   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓
document.getElementById("id17").style.display="";//none隐藏
document.all.title17.innerHTML="『吾优设计师之家资源库』开通试用"//标题
function Link17(){
window.open("http://mp.weixin.qq.com/s/zJEkku-oWD4Ag4afnnV35A"//链接
);}