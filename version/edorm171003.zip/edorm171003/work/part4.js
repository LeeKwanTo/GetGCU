//文字1
document.getElementById("bgword1").style.display="";//none隐藏
document.all.word1.innerHTML="尊敬的客户，您好！您已成功办理“1706124_校园手机宽带暑期特惠活动-赠送30元话费”,感谢您的支持。【中国移动】"//文字1
document.all.wfrom1.innerHTML="暑期宽带费用陆续开始返还，你收到短信了吗？"//来源


	//图1
	document.getElementById("bgpic1").style.display="";//none隐藏
	document.all.pfrom1.innerHTML="学校后勤查大功率声势浩大，多处挂起横幅"//来源


//文字2
document.getElementById("bgword2").style.display="none";//none隐藏
document.all.word2.innerHTML=""//文字2
document.all.wfrom2.innerHTML="来自群聊或者朋友圈"//来源


	//图2
	document.getElementById("bgpic2").style.display="none";//none隐藏
	document.all.pfrom2.innerHTML="来自群聊"//来源


//文字3
document.getElementById("bgword3").style.display="none";//none隐藏
document.all.word3.innerHTML=""//文字3
document.all.wfrom3.innerHTML="来自群聊或者朋友圈"//来源


	//图3
	document.getElementById("bgpic3").style.display="none";//none隐藏
	document.all.pfrom3.innerHTML="来自群聊"//来源



//视频1
document.getElementById("bgpic4").style.display="none";//none隐藏
document.all.pfrom4.innerHTML="来自群聊"//来源



//视频2
document.getElementById("bgpic5").style.display="";//none隐藏
document.all.pfrom5.innerHTML="来自群聊"//来源