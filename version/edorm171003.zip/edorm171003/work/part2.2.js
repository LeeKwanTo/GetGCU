
//  --  Part 2.2  --

//---讲座1
document.getElementById("jz1").style.display="none";//none隐藏
document.getElementById("ijz1").style.display="none";

document.all.jz1title.innerHTML="跨境电商定向人才培养项目宣讲会"//标题
document.all.jz1detail.innerHTML="9月28日（星期四）14:30 图书馆报告厅"//描述
document.all.jz1from.innerHTML="华广青春汇"//来源
function jz1Link(){
window.open("http://mp.weixin.qq.com/s/snQ0YIbvHrP3ThmE7qCS6Q"//链接
);}
document.getElementById("jz1gz").style.display="none";//不盖章none
document.getElementById("ijz1gz").style.display="none";



//---讲座2
document.getElementById("jz2").style.display="none";//none隐藏
document.getElementById("ijz2").style.display="none";

document.all.jz2title.innerHTML="明纬（广州）电子有限公司校园宣讲会"//标题
document.all.jz2detail.innerHTML="9月29日 周五 15：00-17：00 A5-202"//描述
document.all.jz2from.innerHTML="华广就业指导中心"//来源
function jz2Link(){
window.open("http://mp.weixin.qq.com/s/gwoTCPmy-4IphtnQLKIJxw"//链接
);}
document.getElementById("jz2gz").style.display="none";//不盖章none
document.getElementById("ijz2gz").style.display="none";



//---讲座3
document.getElementById("jz3").style.display="none";//none隐藏
document.getElementById("ijz3").style.display="none";

document.all.jz3title.innerHTML="电影风暴 |《哪啊哪啊神去村》"//标题
document.all.jz3detail.innerHTML="9月29日 周五 19：00 A5-201 "//描述
document.all.jz3from.innerHTML="华广读协"//来源
function jz3Link(){
window.open("http://mp.weixin.qq.com/s/3Ao3fy2zk1mlIyNC7ZwEMw"//链接
);}
document.getElementById("jz3gz").style.display="none";//不盖章none
document.getElementById("ijz3gz").style.display="none";



//  讲座4
document.getElementById("jz4").style.display="";//none隐藏
document.getElementById("ijz4").style.display="";

document.all.jz4title.innerHTML="我是标题"//标题
document.all.jz4detail.innerHTML="这是描述"//描述
document.all.jz4from.innerHTML="公众号名称"//来源
function jz4Link(){
window.open("这是链接"//链接
);}
document.getElementById("jz4gz").style.display="";//不盖章none
document.getElementById("ijz4gz").style.display="";



//  讲座5
document.getElementById("jz5").style.display="none";//none隐藏
document.getElementById("ijz5").style.display="none";

document.all.jz5title.innerHTML="我是标题"//标题
document.all.jz5detail.innerHTML="这是描述"//描述
document.all.jz5from.innerHTML="公众号名称"//来源
function jz5Link(){
window.open("这是链接"//链接
);}
document.getElementById("jz5gz").style.display="none";//不盖章none
document.getElementById("ijz5gz").style.display="none";



//  讲座6
document.getElementById("jz6").style.display="none";//none隐藏
document.getElementById("ijz6").style.display="none";

document.all.jz6title.innerHTML="我是标题"//标题
document.all.jz6detail.innerHTML="这是描述"//描述
document.all.jz6from.innerHTML="公众号名称"//来源
function jz6Link(){
window.open("这是链接"//链接
);}
document.getElementById("jz6gz").style.display="none";//不盖章none
document.getElementById("ijz6gz").style.display="none";