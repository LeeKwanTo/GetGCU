
//  --  Part 2.1  --

//  最新资讯1
document.getElementById("new1").style.display="none";//none隐藏
document.all.new1title.innerHTML="明纬（广州）电子有限公司校园宣讲会"//标题
document.all.new1detail.innerHTML="9月29日 周五 15：00-17：00 A5-202"//描述
document.all.new1from.innerHTML=" 华广就业指导中心"//来源
function new1Link(){
window.open("http://mp.weixin.qq.com/s/gwoTCPmy-4IphtnQLKIJxw"//链接
);}
document.getElementById("new1gz").style.display="none";//不盖章none



//  最新资讯2
document.getElementById("new2").style.display="none";//none隐藏
document.all.new2title.innerHTML=""//标题
document.all.new2detail.innerHTML=""//描述
document.all.new2from.innerHTML=""//来源
function new2Link(){
window.open(""//链接
);}
document.getElementById("new2gz").style.display="none";//不盖章none



//  最新资讯3
document.getElementById("new3").style.display="none";//none隐藏
document.all.new3title.innerHTML="知识视界答题比赛"//标题
document.all.new3detail.innerHTML="活动时间：9月20日-10月30日"//描述
document.all.new3from.innerHTML="华广图书馆"//来源
function new3Link(){
window.open("http://mp.weixin.qq.com/s/VpfVOfIVo07xrN5ko7CI0w"//链接
);}
document.getElementById("new3gz").style.display="none";//不盖章none



//  最新资讯4
document.getElementById("new4").style.display="none";//none隐藏
document.all.new4title.innerHTML="学校“创客训练营”大学生创新创业引领计划（第一期）学员招募"//标题
document.all.new4detail.innerHTML="公开报名时间9月20日-9月29日"//描述
document.all.new4from.innerHTML="华广青春汇"//来源
function new4Link(){
window.open("http://mp.weixin.qq.com/s/Gq303tfiOjjd71uiAUIjLQ"//链接
);}
document.getElementById("new4gz").style.display="none";//不盖章none



//  最新资讯5
document.getElementById("new5").style.display="none";//none隐藏
document.all.new5title.innerHTML="【考研】广东2018年硕士研究生招生考试网上报名"//标题
document.all.new5detail.innerHTML="网上预报名时间：2017年9月24日至9月27日，每天9:00-22:00  网上报名时间：2017年10月10日至10月31日，每天9:00-22:00"//描述
document.all.new5from.innerHTML="华广就业指导中心"//来源
function new5Link(){
window.open("http://mp.weixin.qq.com/s/_7a358OSm44F-yY-xKXFFQ"//链接
);}
document.getElementById("new5gz").style.display="none";//不盖章none



//  最新资讯6
document.getElementById("new6").style.display="";//none隐藏
document.all.new6title.innerHTML="招聘信息 | 广州中圣会健身有限公司招聘"//标题
document.all.new6detail.innerHTML=""//描述
document.all.new6from.innerHTML="华广管院学生就业创业促进会"//来源
function new6Link(){
window.open("http://mp.weixin.qq.com/s/89tB04LlEhRwflYYn34pKA"//链接
);}
document.getElementById("new6gz").style.display="none";//不盖章none