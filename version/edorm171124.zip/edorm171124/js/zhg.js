// 二维码弹出与隐藏
$(document).ready(function(){
$("#closecomputer-1").click(function(){$("#ADcomputer").css({'display':'none'})});
$("#closecomputer-2").click(function(){$("#ADcomputer").css({'display':'none'})});
$("#opencomputer").click(function(){$("#ADcomputer").css({'display':'block'})});

$("#closefocus-1").click(function(){$("#ADfocus").css({'display':'none'})});
$("#closefocus-2").click(function(){$("#ADfocus").css({'display':'none'})});
$("#openfocus").click(function(){$("#ADfocus").css({'display':'block'})})
});


$(function(){


        $('.gd_ico').on('click',function(){
            $('.pet_more_list').addClass('pet_more_list_show');
       });
        $('.pet_more_close').on('click',function(){
            $('.pet_more_list').removeClass('pet_more_list_show');
        });
});

//---来自讲座1
document.all.ijz1title.innerHTML=document.all.jz1title.innerHTML//标题
document.all.ijz1detail.innerHTML=document.all.jz1detail.innerHTML//描述
document.all.ijz1fr.innerHTML=document.all.jz1fr.innerHTML//来源
function Lijz1(){
window.location(Ljz1()
);}


//---来自讲座2
document.all.ijz2title.innerHTML=document.all.jz2title.innerHTML//标题
document.all.ijz2detail.innerHTML=document.all.jz2detail.innerHTML//描述
document.all.ijz2fr.innerHTML=document.all.jz2fr.innerHTML//来源
function Lijz2(){
window.location(Ljz2()
);}


//---来自讲座3
document.all.ijz3title.innerHTML=document.all.jz3title.innerHTML//标题
document.all.ijz3detail.innerHTML=document.all.jz3detail.innerHTML//描述
document.all.ijz3fr.innerHTML=document.all.jz3fr.innerHTML//来源
function Lijz3(){
window.location(Ljz3()
);}


//---来自讲座4
document.all.ijz4title.innerHTML=document.all.jz4title.innerHTML//标题
document.all.ijz4detail.innerHTML=document.all.jz4detail.innerHTML//描述
document.all.ijz4fr.innerHTML=document.all.jz4fr.innerHTML//来源
function Lijz4(){
window.location(Ljz4()
);}


//---来自讲座5
document.all.ijz5title.innerHTML=document.all.jz5title.innerHTML//标题
document.all.ijz5detail.innerHTML=document.all.jz5detail.innerHTML//描述
document.all.ijz5fr.innerHTML=document.all.jz5fr.innerHTML//来源
function Lijz5(){
window.location(Ljz5()
);}


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

//---来自比赛1
document.all.ibs1title.innerHTML=document.all.bs1title.innerHTML//标题
document.all.ibs1detail.innerHTML=document.all.bs1detail.innerHTML//描述
document.all.ibs1fr.innerHTML=document.all.bs1fr.innerHTML//来源
function Libs1(){
window.location(Lbs1()
);}


//---来自比赛2
document.all.ibs2title.innerHTML=document.all.bs2title.innerHTML//标题
document.all.ibs2detail.innerHTML=document.all.bs2detail.innerHTML//描述
document.all.ibs2fr.innerHTML=document.all.bs2fr.innerHTML//来源
function Libs2(){
window.location(Lbs2()
);}


//---来自比赛3
document.all.ibs3title.innerHTML=document.all.bs3title.innerHTML//标题
document.all.ibs3detail.innerHTML=document.all.bs3detail.innerHTML//描述
document.all.ibs3fr.innerHTML=document.all.bs3fr.innerHTML//来源
function Libs3(){
window.location(Lbs3()
);}


//---来自比赛4
document.all.ibs4title.innerHTML=document.all.bs4title.innerHTML//标题
document.all.ibs4detail.innerHTML=document.all.bs4detail.innerHTML//描述
document.all.ibs4fr.innerHTML=document.all.bs4fr.innerHTML//来源
function Libs4(){
window.location(Lbs4()
);}


//---来自比赛5
document.all.ibs5title.innerHTML=document.all.bs5title.innerHTML//标题
document.all.ibs5detail.innerHTML=document.all.bs5detail.innerHTML//描述
document.all.ibs5fr.innerHTML=document.all.bs5fr.innerHTML//来源
function Libs5(){
window.location(Lbs5()
);}
