
//  --  Part 2.1  --

//  最新资讯1
document.getElementById("new1").style.display="none";//none隐藏
document.all.new1title.innerHTML="明纬（广州）电子有限公司校园宣讲会"//标题
document.all.new1detail.innerHTML="9月29日 周五 15：00-17：00 A5-202"//描述
document.all.new1fr.innerHTML=" 华广就业指导中心"//来源
function Lnew1(){
window.open("http://mp.weixin.qq.com/s/gwoTCPmy-4IphtnQLKIJxw"//链接
);}
document.getElementById("new1g").style.display="none";//不盖章none



//  最新资讯2
document.getElementById("new2").style.display="none";//none隐藏
document.all.new2title.innerHTML=""//标题
document.all.new2detail.innerHTML=""//描述
document.all.new2fr.innerHTML=""//来源
function Lnew2(){
window.open(""//链接
);}
document.getElementById("new2g").style.display="none";//不盖章none



//  最新资讯3
document.getElementById("new3").style.display="none";//none隐藏
document.all.new3title.innerHTML="知识视界答题比赛"//标题
document.all.new3detail.innerHTML="活动时间：9月20日-10月30日"//描述
document.all.new3fr.innerHTML="华广图书馆"//来源
function Lnew3(){
window.open("http://mp.weixin.qq.com/s/VpfVOfIVo07xrN5ko7CI0w"//链接
);}
document.getElementById("new3g").style.display="none";//不盖章none



//  最新资讯4
document.getElementById("new4").style.display="none";//none隐藏
document.all.new4title.innerHTML="我是标题"//标题
document.all.new4detail.innerHTML="我是描述"//描述
document.all.new4fr.innerHTML="公众号名字"//来源
function Lnew4(){
window.open("http://mp.weixin.qq.com/s/Gq303tfiOjjd71uiAUIjLQ"//链接
);}
document.getElementById("new4g").style.display="none";//不盖章none



//  最新资讯5
document.getElementById("new5").style.display="none";//none隐藏
document.all.new5title.innerHTML="【考研】广东2018年硕士研究生招生考试网上报名"//标题
document.all.new5detail.innerHTML="网上报名时间：2017年10月10日至10月31日，每天9:00-22:00"//描述
document.all.new5fr.innerHTML="华广就业指导中心"//来源
function Lnew5(){
window.open("http://mp.weixin.qq.com/s/_7a358OSm44F-yY-xKXFFQ"//链接
);}
document.getElementById("new5g").style.display="none";//不盖章none



//  最新资讯6
document.getElementById("new6").style.display="";//none隐藏
document.all.new6title.innerHTML="招聘信息 | 广州中圣会健身有限公司招聘"//标题
document.all.new6detail.innerHTML=""//描述
document.all.new6fr.innerHTML="华广管院学生就业创业促进会"//来源
function Lnew6(){
window.open("http://mp.weixin.qq.com/s/89tB04LlEhRwflYYn34pKA"//链接
);}
document.getElementById("new6g").style.display="none";//不盖章none