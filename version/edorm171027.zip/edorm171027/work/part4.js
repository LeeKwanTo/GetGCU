//文字1
document.getElementById("hword1").style.display="none";//none隐藏
document.all.w1.innerHTML="以下内容来自朋友圈"//内容
document.all.wfr1.innerHTML=""//来源


	//图1 hi.jpg
	document.getElementById("hpic1").style.display="none";//none隐藏
	document.all.pfr1.innerHTML="缉毒大队？ 图片来自朋友圈"//来源


//文字2
document.getElementById("hword2").style.display="none";//none隐藏
document.all.w2.innerHTML=""//内容
document.all.wfr2.innerHTML="来自群聊或者朋友圈"//来源


	//图2 h2.jpg
	document.getElementById("hpic2").style.display="none";//none隐藏
	document.all.pfr2.innerHTML="宿舍楼下 图片来自朋友圈"//来源


//文字3
document.getElementById("hword3").style.display="none";//none隐藏
document.all.w3.innerHTML=""//内容
document.all.wfr3.innerHTML="来自群聊或者朋友圈"//来源


	//图3 h3.jpg
	document.getElementById("hpic3").style.display="none";//none隐藏
	document.all.pfr3.innerHTML="图片来自朋友圈"//来源



//视频1 mv1.jpg
document.getElementById("mv1").style.display="none";//none隐藏
document.all.mfr1.innerHTML="视频来自群聊"//来源



//视频2 mv2.jpg
document.getElementById("mv2").style.display="none";//none隐藏
document.all.mfr2.innerHTML="视频来自群聊"//来源