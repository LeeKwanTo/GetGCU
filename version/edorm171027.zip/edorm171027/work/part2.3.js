
//  --  Part 2.3  --

//  比赛1
document.getElementById("bs1").style.display="none";//none隐藏
document.getElementById("ibs1").style.display="none";

document.all.bs1title.innerHTML="“图书馆之美”摄影大赛"//标题
document.all.bs1detail.innerHTML="活动时间：10月23日至11月1日"//描述
document.all.bs1fr.innerHTML="华广管理学院团委学生会"//来源
function Lbs1(){
window.open("https://mp.weixin.qq.com/s/kYylolSG8DhxorH3EFundA"//链接
);}
document.getElementById("bs1g").style.display="none";//不盖章none
document.getElementById("ibs1g").style.display="none";



//  比赛2
document.getElementById("bs2").style.display="";//none隐藏
document.getElementById("ibs2").style.display="";

document.all.bs2title.innerHTML="“图书馆之美”摄影大赛"//标题
document.all.bs2detail.innerHTML="活动时间：10月23日至11月1日"//描述
document.all.bs2fr.innerHTML="华广图书馆"//来源
function Lbs2(){
window.open("http://mp.weixin.qq.com/s/kYylolSG8DhxorH3EFundA"//链接
);}
document.getElementById("bs2g").style.display="none";//不盖章none
document.getElementById("ibs2g").style.display="none";



// 比赛3
document.getElementById("bs3").style.display="none";//none隐藏
document.getElementById("ibs3").style.display="none";

document.all.bs3title.innerHTML="管理学院校友会LOGO设计大赛来啦"//标题
document.all.bs3detail.innerHTML="线上报名10月14日截止，线下报名10月09日-10月11日"//描述
document.all.bs3fr.innerHTML="华广管院校友会"//来源
function Lbs3(){
window.open("http://mp.weixin.qq.com/s/rLW0ByaFTrWZKre1BrPF1A"//链接
);}
document.getElementById("bs3g").style.display="none";//不能盖章none
document.getElementById("ibs3g").style.display="none";



// 比赛4
document.getElementById("bs4").style.display="none";//none隐藏
document.getElementById("ibs4").style.display="none";

document.all.bs4title.innerHTML="我是标题"//标题
document.all.bs4detail.innerHTML="这是描述"//描述
document.all.bs4fr.innerHTML="公众号名称"//来源
function Lbs4(){
window.open("这是链接"//链接
);}
document.getElementById("bs4g").style.display="none";//不能盖章none
document.getElementById("ibs4g").style.display="none";



// 比赛5
document.getElementById("bs5").style.display="none";//none隐藏
document.getElementById("ibs5").style.display="none";

document.all.bs5title.innerHTML="我是标题"//标题
document.all.bs5detail.innerHTML="这是描述"//描述
document.all.bs5fr.innerHTML="公众号名称"//来源
function Lbs5(){
window.open("这是链接"//链接
);}
document.getElementById("bs5g").style.display="none";//不盖章none
document.getElementById("ibs5g").style.display="none";
