//---来自讲座1
document.all.ijz1title.innerHTML=document.all.jz1title.innerHTML//标题
document.all.ijz1detail.innerHTML=document.all.jz1detail.innerHTML//描述
document.all.ijz1from.innerHTML=document.all.jz1from.innerHTML//来源
function ijz1Link(){
window.location(jz1Link()
);}


//---来自讲座2
document.all.ijz2title.innerHTML=document.all.jz2title.innerHTML//标题
document.all.ijz2detail.innerHTML=document.all.jz2detail.innerHTML//描述
document.all.ijz2from.innerHTML=document.all.jz2from.innerHTML//来源
function ijz2Link(){
window.location(jz2Link()
);}


//---来自讲座3
document.all.ijz3title.innerHTML=document.all.jz3title.innerHTML//标题
document.all.ijz3detail.innerHTML=document.all.jz3detail.innerHTML//描述
document.all.ijz3from.innerHTML=document.all.jz3from.innerHTML//来源
function ijz3Link(){
window.location(jz3Link()
);}


//---来自讲座4
document.all.ijz4title.innerHTML=document.all.jz4title.innerHTML//标题
document.all.ijz4detail.innerHTML=document.all.jz4detail.innerHTML//描述
document.all.ijz4from.innerHTML=document.all.jz4from.innerHTML//来源
function ijz4Link(){
window.location(jz4Link()
);}


//---来自讲座5
document.all.ijz5title.innerHTML=document.all.jz5title.innerHTML//标题
document.all.ijz5detail.innerHTML=document.all.jz5detail.innerHTML//描述
document.all.ijz5from.innerHTML=document.all.jz5from.innerHTML//来源
function ijz5Link(){
window.location(jz5Link()
);}


//---来自讲座6
document.all.ijz6title.innerHTML=document.all.jz6title.innerHTML//标题
document.all.ijz6detail.innerHTML=document.all.jz6detail.innerHTML//描述
document.all.ijz6from.innerHTML=document.all.jz6from.innerHTML//来源
function ijz6Link(){
window.location(jz5Link()
);}



//---来自比赛1
document.all.ibs1title.innerHTML=document.all.bs1title.innerHTML//标题
document.all.ibs1detail.innerHTML=document.all.bs1detail.innerHTML//描述
document.all.ibs1from.innerHTML=document.all.bs1from.innerHTML//来源
function ibs1Link(){
window.location(bs1Link()
);}


//---来自比赛2
document.all.ibs2title.innerHTML=document.all.bs2title.innerHTML//标题
document.all.ibs2detail.innerHTML=document.all.bs2detail.innerHTML//描述
document.all.ibs2from.innerHTML=document.all.bs2from.innerHTML//来源
function ibs2Link(){
window.location(bs2Link()
);}


//---来自比赛3
document.all.ibs3title.innerHTML=document.all.bs3title.innerHTML//标题
document.all.ibs3detail.innerHTML=document.all.bs3detail.innerHTML//描述
document.all.ibs3from.innerHTML=document.all.bs3from.innerHTML//来源
function ibs3Link(){
window.location(bs3Link()
);}


//---来自比赛4
document.all.ibs4title.innerHTML=document.all.bs4title.innerHTML//标题
document.all.ibs4detail.innerHTML=document.all.bs4detail.innerHTML//描述
document.all.ibs4from.innerHTML=document.all.bs4from.innerHTML//来源
function ibs4Link(){
window.location(bs4Link()
);}


//---来自比赛5
document.all.ibs5title.innerHTML=document.all.bs5title.innerHTML//标题
document.all.ibs5detail.innerHTML=document.all.bs5detail.innerHTML//描述
document.all.ibs5from.innerHTML=document.all.bs5from.innerHTML//来源
function ibs5Link(){
window.location(bs5Link()
);}


//---来自比赛6
document.all.ibs6title.innerHTML=document.all.bs6title.innerHTML//标题
document.all.ibs6detail.innerHTML=document.all.bs6detail.innerHTML//描述
document.all.ibs6from.innerHTML=document.all.bs6from.innerHTML//来源
function ibs6Link(){
window.location(bs5Link()
);}