//---讲座1
document.getElementById("jz1").style.display="none";//none隐藏
document.getElementById("ijz1").style.display="none";

document.all.jz1title.innerHTML="华广专场| #广东文都教育2019考研系列讲座之早知道#"//标题
document.all.jz1detail.innerHTML="9月7日 19:00 A3-110"//描述
document.all.jz1from.innerHTML="华广人力资源学研会"//来源
function jz1Link(){
window.open("http://mp.weixin.qq.com/s/KaafLndp8Klro1yhfrmW6w"//链接
);}
document.getElementById("jz1gz").style.display="none";//不能盖章none
document.getElementById("ijz1gz").style.display="none";





//---讲座2
document.getElementById("jz2").style.display="";//none隐藏
document.getElementById("ijz2").style.display="";

document.all.jz2title.innerHTML="英语口语学习技巧"//标题
document.all.jz2detail.innerHTML="9月14日 19：00 A6-101"//描述
document.all.jz2from.innerHTML="华广外国语学院团委学生会"//来源
function jz2Link(){
window.open("http://mp.weixin.qq.com/s/vUSTkI1_Jt31E1oJVd_YCA"//链接
);}
document.getElementById("jz2gz").style.display="none";//不能盖章none
document.getElementById("ijz2gz").style.display="none";





//---讲座3
document.getElementById("jz3").style.display="none";//none隐藏
document.getElementById("ijz3").style.display="none";

document.all.jz3title.innerHTML="我是标题"//标题
document.all.jz3detail.innerHTML="这是描述"//描述
document.all.jz3from.innerHTML="公众号名称"//来源
function jz3Link(){
window.open("这是链接"//链接
);}
document.getElementById("jz3gz").style.display="none";//不能盖章none
document.getElementById("ijz3gz").style.display="none";





//---讲座4
document.getElementById("jz4").style.display="none";//none隐藏
document.getElementById("ijz4").style.display="none";

document.all.jz4title.innerHTML="我是标题"//标题
document.all.jz4detail.innerHTML="这是描述"//描述
document.all.jz4from.innerHTML="公众号名称"//来源
function jz4Link(){
window.open("这是链接"//链接
);}
document.getElementById("jz4gz").style.display="none";//不能盖章none
document.getElementById("ijz4gz").style.display="none";





//---讲座5
document.getElementById("jz5").style.display="none";//none隐藏
document.getElementById("ijz5").style.display="none";

document.all.jz5title.innerHTML="我是标题"//标题
document.all.jz5detail.innerHTML="这是描述"//描述
document.all.jz5from.innerHTML="公众号名称"//来源
function jz5Link(){
window.open("这是链接"//链接
);}
document.getElementById("jz5gz").style.display="none";//不能盖章none
document.getElementById("ijz5gz").style.display="none";





//---讲座6
document.getElementById("jz6").style.display="none";//none隐藏
document.getElementById("ijz6").style.display="none";

document.all.jz6title.innerHTML="我是标题"//标题
document.all.jz6detail.innerHTML="这是描述"//描述
document.all.jz6from.innerHTML="公众号名称"//来源
function jz6Link(){
window.open("这是链接"//链接
);}
document.getElementById("jz6gz").style.display="none";//不能盖章none
document.getElementById("ijz6gz").style.display="none";