
//  --  Part 3  --


// 09 - 视频   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓  视频推文如果是微信推文里的，填http://edorm.yowoit.com/work/shipin3.html
document.getElementById("m09").style.display="none";//none隐藏
document.all.title09.innerHTML="唱响新声 | 那些你错过的精彩"//标题
document.all.time09.innerHTML="43:14"//时长
function L09(){
window.open("http://edorm.yowoit.com/work/shipin3.html"//链接
);}


// 10 - 大图   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓
document.getElementById("m10").style.display="none";//none隐藏
document.all.title10.innerHTML="学无止境丨讲座概览"//标题
function L10(){
window.open("http://mp.weixin.qq.com/s/AXBg_SHMtsnYmbSHcdMteg"//链接
);}


// 11 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("m11").style.display="";//none隐藏
document.all.title11.innerHTML="期待已久的华广四饭外卖终于来啦"//标题
document.all.fr11.innerHTML="广州壹心膳食"//来源
function L11(){
window.open("http://mp.weixin.qq.com/s/PxbeESsEzL4fXGrII79dwg"//链接
);}



// 12 - 3图图文   ███   ███  ███
//               121   122  123
document.getElementById("m12").style.display="none";//none隐藏
document.all.title12.innerHTML="告别军训 | 不过13天却是波及一生的回忆"//标题
document.all.fr12.innerHTML="华管人"//来源
function L12(){
window.open("http://mp.weixin.qq.com/s/r7Q9EYogPXZ1opQ6TDRr7A"//链接
);}


// 13 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("m13").style.display="";//none隐藏
document.all.title13.innerHTML="富泰超市寻宝：寻找迷失在超市里面的公仔"//标题
document.all.fr13.innerHTML="华广有料"//来源
function L13(){
window.open("http://mp.weixin.qq.com/s/NgnZNYaE11hSkym0rSglog"//链接
);}


// 14 - 通知 ▽
// 
document.getElementById("m14").style.display="none";//none隐藏
document.all.title14.innerHTML="社团联合招新时间调整"//标题
document.all.fr14.innerHTML="华广学生社团联合会"//来源
document.all.detail14.innerHTML=
" "//通知内容
//function L14(){window.open("");}//链接
document.getElementById("m14img").style.display="";//无图片none


// 15 - 图文  ∷∷∷ ▇▇
// 
document.getElementById("m15").style.display="";//none隐藏
document.all.title15.innerHTML="11月2日|华广兼职"//标题
document.all.fr15.innerHTML="华广招聘"//来源
function L15(){
window.open("http://mp.weixin.qq.com/s/KDCi9PPAlTuFnktfvBxXVw"//链接
);}



// 16 - 图文（表白墙专用）
// 
document.getElementById("m16").style.display="none";//none隐藏
document.all.title16.innerHTML="华广表白墙第四十九期"//标题
document.all.fr16.innerHTML="纵梦华广"//来源
function L16(){
window.open("http://mp.weixin.qq.com/s/YlOQRUWFHW0GA1ik4qIMJQ"//链接
);}



// 17 - 大图   ‥‥‥‥‥
//    ▽       ▓▓▓▓▓
document.getElementById("m17").style.display="none";//none隐藏
document.all.title17.innerHTML="【官方回应】世上最严检查大功率破门而入？是谣言"//标题
function L17(){
window.open("https://mp.weixin.qq.com/s/NWTlqIF-mLQRKckRIKnp"//链接
);}