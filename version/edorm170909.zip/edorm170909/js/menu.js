document.all.head1.innerHTML="头条"//头部菜单1
function head1(){
window.open("http://edorm.yowoit.com"//链接
);}


document.all.head3.innerHTML="买电脑"//头部菜单3
