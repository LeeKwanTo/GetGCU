//---模块01---图文---图片01.jpg
document.getElementById("id01").style.display="";//none为隐藏
document.all.title01.innerHTML="在华广度过美好的一个月，需要多少钱？"//标题
document.all.from01.innerHTML="华工广州学院招生办"//来源
function Link01(){
window.open("http://mp.weixin.qq.com/s/W8WoQ_XuQUelYv1NCxV0Nw"//链接
);}



//---模块02---大图广告---图片02.jpg
document.getElementById("id02").style.display="none";//none为隐藏
document.all.title02.innerHTML="这是标题"//标题
function Link02(){
window.open("这是链接"//链接
);}



//---模块03---图文---图片03.jpg
document.getElementById("id03").style.display="";//none为隐藏
document.all.title03.innerHTML="文 | 最悲哀的教育，是寒门养“贵子”"//标题
document.all.from03.innerHTML="读者"//来源
function Link03(){
window.open("http://mp.weixin.qq.com/s/2sLjjcusc_W_adLDQZndtQ"//链接
);}



//---模块04---视频---图片04.jpg
document.getElementById("id04").style.display="";//none为隐藏
document.all.title04.innerHTML="华广招生宣传片"//标题
document.all.time04.innerHTML="6∶53"//时长
function Link04(){
window.open("https://v.qq.com/x/page/f0308mjtl73.html"//链接
);}



//---模块05---图文---图片05.jpg
document.getElementById("id05").style.display="none";//none为隐藏
document.all.title05.innerHTML="我是标题"//标题
document.all.from05.innerHTML="公众号名称"//来源
function Link05(){
window.open("这是链接"//链接
);}



//---模块06---图片欣赏---图片061.jpg 062.jpg 063.jpg
document.getElementById("id06").style.display="none";//none为隐藏
document.all.title06.innerHTML="【图片欣赏】华广｜柔和几何"//标题
document.all.from06.innerHTML="HiSam"//来源
function Link06(){
window.open("http://mp.weixin.qq.com/s/t6AGwhVx93sDlm-yXYcE8w"//链接
);}



//---模块07---3图图文---图片071.jpg 072.jpg 073.jpg
document.getElementById("id07").style.display="none";//none为隐藏
document.all.title07.innerHTML="我是标题"//标题
document.all.from07.innerHTML="公众号名称"//来源
function Link07(){
window.open("这是链接"//链接
);}



