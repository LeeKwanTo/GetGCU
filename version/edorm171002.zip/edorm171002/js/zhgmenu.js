document.all.head1.innerHTML="头条"//头部菜单1
function head1(){
window.open("http://edorm.yowoit.com"//链接
);}

document.all.head2.innerHTML="服务墙"//头部菜单2
function head2(){
window.open("http://edorm.yowoit.com/menu/serwall.html"//链接
);}

document.all.head3.innerHTML="校外事"//头部菜单3
function head3(){
window.open("http://buser.giiso.com/auth/login.jsp?appId=C0004710001&appType=3"//链接
);}

document.all.head4.innerHTML="买电脑"//头部菜单4



document.all.kind1.innerHTML="华广百事通"//大分类1标题

document.all.kind101.innerHTML="校历"//分类1-1标题
function link101(){
window.open("http://edorm.yowoit.com/menu/xiaoli.html"//链接
);}

document.all.kind102.innerHTML="公交"//分类1-2标题
function link102(){
window.open("http://edorm.yowoit.com/menu/bus.html"//链接
);}

document.all.kind103.innerHTML="地铁"//分类1-3标题
function link103(){
window.open("http://edorm.yowoit.com/menu/metro.html"//链接
);}

document.all.kind104.innerHTML="医疗"//分类1-4标题
function link104(){
window.open("http://edorm.yowoit.com/menu/medical.html"//链接
);}

document.all.kind105.innerHTML="后勤"//分类1-5标题
function link105(){
window.open("http://edorm.yowoit.com/menu/houqin.html"//链接
);}

document.all.kind106.innerHTML="教务"//分类1-6标题
function link106(){
window.open("http://jwxt.gcu.edu.cn/"//链接
);}

document.all.kind107.innerHTML="外卖"//分类1-7标题
function link107(){
window.open("http://edorm.yowoit.com/menu/waimai.html"//链接
);}

document.all.kind108.innerHTML="地图"//分类1-8标题
function link108(){
window.open("http://edorm.yowoit.com/menu/map.html"//链接
);}

document.getElementById("idkind109").style.display="none";//none为隐藏
document.all.kind109.innerHTML="名称"//分类1-9标题
function link109(){
window.open("###"//链接
);}



document.all.kind2.innerHTML="服务 Service"//大分类2标题


document.all.kind201.innerHTML="宿舍群"//分类2-1标题
function link201(){
window.open("http://edorm.yowoit.com/menu/sushequn.html"//链接
);}

document.all.kind202.innerHTML="开网"//分类2-2标题
function link202(){
window.open("http://edorm.yowoit.com/menu/network.html"//链接
);}

document.all.kind203.innerHTML="流量"//分类2-3标题
function link203(){

if (confirm("即将进入广州移动和商汇微店，该页内容由广州移动提供。")){  
            window.open("http://h5.gmccopen.com/act/portalwei2!home.action?channelId=gzweidian&storeid=C39586&serviceid=&type=01");  
        } 
}

document.all.kind204.innerHTML="查图书"//分类2-4标题
function link204(){
	if (confirm("若打开后无法查询，请关注公众号“华广图书馆”后再尝试")){  
            window.open("http://cloud.zhaobenshu.com:7783/custom/zbsHome/wap/_c1/page/home.html");  
        } 
}

document.all.kind205.innerHTML="查快递"//分类2-5标题
function link205(){
window.open("http://weixin.diyibox.com/index.php/Query/index"//链接
);}

document.all.kind206.innerHTML="取快递"//分类2-6标题
function link206(){
window.open("http://weixin.diyibox.com/index.php/Collect/replace"//链接
);}

document.all.kind207.innerHTML="寄快递"//分类2-7标题
function link207(){
window.open("http://weixin.diyibox.com/index.php/Sender/new_send?code=0112dJVx0Deezf1JDIWx04ECVx02dJVd&state=STATE"//链接
);}

document.all.kind208.innerHTML="网管"//分类2-8标题
function link208(){
window.open("http://ncwx.gcu.edu.cn/home/Wxinformation/networkManager_index"//链接
);}

document.getElementById("idkind209").style.display="none";//none为隐藏
document.all.kind209.innerHTML="待定"//分类2-9标题
function link209(){
window.open("###"//链接
);}