
//  --  Part 2.2  --

//---讲座1
document.getElementById("jz1").style.display="none";//none隐藏
document.getElementById("ijz1").style.display="none";

document.all.jz1title.innerHTML="学海无涯，知网作舟 讲座"//标题
document.all.jz1detail.innerHTML="10月20日  18:30 A5-201"//描述
document.all.jz1fr.innerHTML="华广图书馆"//来源
function Ljz1(){
window.open("http://mp.weixin.qq.com/s/KyKY-96sYlhMEOMqbz64_g"//链接
);}
document.getElementById("jz1g").style.display="none";//不盖章none
document.getElementById("ijz1g").style.display="none";



//---讲座2
document.getElementById("jz2").style.display="none";//none隐藏
document.getElementById("ijz2").style.display="none";

document.all.jz2title.innerHTML="证券知识讲座"//标题
document.all.jz2detail.innerHTML="10月20日（本周五）19:00 A5－404"//描述
document.all.jz2fr.innerHTML="华广管理学院团委学生会"//来源
function Ljz2(){
window.open("http://mp.weixin.qq.com/s/tYxiRBOXLfiEZe7EYM3utg"//链接
);}
document.getElementById("jz2g").style.display="none";//不盖章none
document.getElementById("ijz2g").style.display="none";



//---讲座3
document.getElementById("jz3").style.display="none";//none隐藏
document.getElementById("ijz3").style.display="none";

document.all.jz3title.innerHTML=""//标题
document.all.jz3detail.innerHTML=""//描述
document.all.jz3fr.innerHTML=""//来源
function Ljz3(){
window.open(""//链接
);}
document.getElementById("jz3g").style.display="none";//不盖章none
document.getElementById("ijz3g").style.display="none";



//  讲座4
document.getElementById("jz4").style.display="none";//none隐藏
document.getElementById("ijz4").style.display="none";

document.all.jz4title.innerHTML="广发银行——广发卡2018校园招聘之华工广州学院专场招聘宣讲会"//标题
document.all.jz4detail.innerHTML="10月19日，下午14:30 图书馆报告厅"//描述
document.all.jz4fr.innerHTML="华广就业指导中心"//来源
function Ljz4(){
window.open("http://mp.weixin.qq.com/s/Dwz5bRrciP4gevOXJ81fWA"//链接
);}
document.getElementById("jz4g").style.display="none";//不盖章none
document.getElementById("ijz4g").style.display="none";



//  讲座5
document.getElementById("jz5").style.display="none";//none隐藏
document.getElementById("ijz5").style.display="none";

document.all.jz5title.innerHTML="我是标题"//标题
document.all.jz5detail.innerHTML="这是描述"//描述
document.all.jz5fr.innerHTML="公众号名称"//来源
function Ljz5(){
window.open("这是链接"//链接
);}
document.getElementById("jz5g").style.display="none";//不盖章none
document.getElementById("ijz5g").style.display="none";
