//----C15栋服务墙

//图片名称为编号，例：第一项服务描述图片为01.jpg
//二维码名称为"q+编号"，例：第一项服务二维码为q01.jpg

//---服务 01
document.getElementById("id01").style.display="none";//none隐藏
document.getElementById("img01").style.display="none";//none隐藏图片
document.all.title01.innerHTML="网管某某某"//标题
document.all.detail01.innerHTML="某某宿舍"//描述
function phone01(){window.open("tel:13527759662"//长号
);}
function dh01(){window.open("tel:689662"//短号
);}
document.all.remark01.innerHTML="备注"//备注


//---服务 02
document.getElementById("id02").style.display="";//none隐藏
document.getElementById("img02").style.display="none";//none隐藏图片
document.all.title02.innerHTML="网管 程建宇"//标题
document.all.detail02.innerHTML="2014级"//描述
function phone02(){window.open("tel:18826241829"//长号
);}
function dh02(){window.open("tel:611829"//短号
);}
document.all.remark02.innerHTML=""//备注


//---服务 03
document.getElementById("id03").style.display="";//none隐藏
document.getElementById("img03").style.display="none";//none隐藏图片
document.all.title03.innerHTML="网管 邹顺汀"//标题
document.all.detail03.innerHTML="2014级"//描述
function phone03(){window.open("tel:18826240275"//长号
);}
function dh03(){window.open("tel:620275"//短号
);}
document.all.remark03.innerHTML=""//备注


//---服务 04
document.getElementById("id04").style.display="none";//none隐藏
document.getElementById("img04").style.display="none";//none隐藏图片
document.all.title04.innerHTML=""//标题
document.all.detail04.innerHTML=""//描述
function phone04(){window.open(""//长号
);}
function dh04(){window.open(""//短号
);}
document.all.remark04.innerHTML=""//备注


//---服务 05
document.getElementById("id05").style.display="";//none隐藏
document.getElementById("img05").style.display="none";//none隐藏图片
document.all.title05.innerHTML="网管 张文龙"//标题
document.all.detail05.innerHTML="2014级"//描述
function phone05(){window.open("tel:18826240568"//长号
);}
function dh05(){window.open("tel:620568"//短号
);}
document.all.remark05.innerHTML=""//备注


//---服务 06
document.getElementById("id06").style.display="none";//none隐藏
document.getElementById("img06").style.display="none";//none隐藏图片
document.all.title06.innerHTML="我是大标题6"//标题
document.all.detail06.innerHTML="详情描述"//描述
function phone06(){window.open("tel:13527759662"//长号
);}
function dh06(){window.open("tel:689662"//短号
);}
document.all.remark06.innerHTML="备注"//备注


//---服务 07
document.getElementById("id07").style.display="none";//none隐藏
document.getElementById("img07").style.display="none";//none隐藏图片
document.all.title07.innerHTML="我是大标题"//标题
document.all.detail07.innerHTML="详情描述"//描述
function phone07(){window.open("tel:13527759662"//长号
);}
function dh07(){window.open("tel:689662"//短号
);}
document.all.remark07.innerHTML="备注"//备注


//---服务 08
document.getElementById("id08").style.display="none";//none隐藏
document.getElementById("img08").style.display="none";//none隐藏图片
document.all.title08.innerHTML="我是大标题"//标题
document.all.detail08.innerHTML="详情描述"//描述
function phone08(){window.open("tel:13527759662"//长号
);}
function dh08(){window.open("tel:689662"//短号
);}
document.all.remark08.innerHTML="备注"//备注


//---服务 09
document.getElementById("id09").style.display="none";//none隐藏
document.getElementById("img09").style.display="none";//none隐藏图片
document.all.title09.innerHTML="我是大标题"//标题
document.all.detail09.innerHTML="详情描述"//描述
function phone09(){window.open("tel:13527759662"//长号
);}
function dh09(){window.open("tel:689662"//短号
);}
document.all.remark09.innerHTML="备注"//备注


//---服务 10
document.getElementById("id10").style.display="none";//none隐藏
document.getElementById("img10").style.display="none";//none隐藏图片
document.all.title10.innerHTML="我是大标题"//标题
document.all.detail10.innerHTML="详情描述"//描述
function phone10(){window.open("tel:13527759662"//长号
);}
function dh10(){window.open("tel:689662"//短号
);}
document.all.remark10.innerHTML="备注"//备注


//---服务 11
document.getElementById("id11").style.display="none";//none隐藏
document.getElementById("img11").style.display="none";//none隐藏图片
document.all.title11.innerHTML="我是大标题"//标题
document.all.detail11.innerHTML="详情描述"//描述
function phone11(){window.open("tel:13527759662"//长号
);}
function dh11(){window.open("tel:689662"//短号
);}
document.all.remark11.innerHTML="备注"//备注


//---服务 12
document.getElementById("id12").style.display="none";//none隐藏
document.getElementById("img12").style.display="none";//none隐藏图片
document.all.title12.innerHTML="我是大标题"//标题
document.all.detail12.innerHTML="详情描述"//描述
function phone12(){window.open("tel:13527759662"//长号
);}
function dh12(){window.open("tel:689662"//短号
);}
document.all.remark12.innerHTML="备注"//备注


//---服务 13
document.getElementById("id13").style.display="none";//none隐藏
document.getElementById("img13").style.display="none";//none隐藏图片
document.all.title13.innerHTML="我是大标题"//标题
document.all.detail13.innerHTML="详情描述"//描述
function phone13(){window.open("tel:13527759662"//长号
);}
function dh13(){window.open("tel:689662"//短号
);}
document.all.remark13.innerHTML="备注"//备注


//---服务 14
document.getElementById("id14").style.display="none";//none隐藏
document.getElementById("img14").style.display="none";//none隐藏图片
document.all.title14.innerHTML="我是大标题"//标题
document.all.detail14.innerHTML="详情描述"//描述
function phone14(){window.open("tel:13527759662"//长号
);}
function dh14(){window.open("tel:689662"//短号
);}
document.all.remark14.innerHTML="备注"//备注


//---服务 15
document.getElementById("id15").style.display="none";//none隐藏
document.getElementById("img15").style.display="none";//none隐藏图片
document.all.title15.innerHTML="我是大标题"//标题
document.all.detail15.innerHTML="详情描述"//描述
function phone15(){window.open("tel:13527759662"//长号
);}
function dh15(){window.open("tel:689662"//短号
);}
document.all.remark15.innerHTML="备注"//备注


//---服务 16
document.getElementById("id16").style.display="none";//none隐藏
document.getElementById("img16").style.display="none";//none隐藏图片
document.all.title16.innerHTML="我是大标题"//标题
document.all.detail16.innerHTML="详情描述"//描述
function phone16(){window.open("tel:13527759662"//长号
);}
function dh16(){window.open("tel:689662"//短号
);}
document.all.remark16.innerHTML="备注"//备注


//---服务 17
document.getElementById("id17").style.display="none";//none隐藏
document.getElementById("img17").style.display="none";//none隐藏图片
document.all.title17.innerHTML="我是大标题"//标题
document.all.detail17.innerHTML="详情描述"//描述
function phone17(){window.open("tel:13527759662"//长号
);}
function dh17(){window.open("tel:689662"//短号
);}
document.all.remark17.innerHTML="备注"//备注


//---服务 18
document.getElementById("id18").style.display="none";//none隐藏
document.getElementById("img18").style.display="none";//none隐藏图片
document.all.title18.innerHTML="我是大标题"//标题
document.all.detail18.innerHTML="详情描述"//描述
function phone18(){window.open("tel:13527759662"//长号
);}
function dh18(){window.open("tel:689662"//短号
);}
document.all.remark18.innerHTML="备注"//备注


//---服务 19
document.getElementById("id19").style.display="none";//none隐藏
document.getElementById("img19").style.display="none";//none隐藏图片
document.all.title19.innerHTML="我是大标题"//标题
document.all.detail19.innerHTML="详情描述"//描述
function phone19(){window.open("tel:13527759662"//长号
);}
function dh19(){window.open("tel:689662"//短号
);}
document.all.remark19.innerHTML="备注"//备注


//---服务 20
document.getElementById("id20").style.display="none";//none隐藏
document.getElementById("img20").style.display="none";//none隐藏图片
document.all.title20.innerHTML="我是大标题"//标题
document.all.detail20.innerHTML="详情描述"//描述
function phone20(){window.open("tel:13527759662"//长号
);}
function dh20(){window.open("tel:689662"//短号
);}
document.all.remark20.innerHTML="备注"//备注


//---服务 21
document.getElementById("id21").style.display="none";//none隐藏
document.getElementById("img21").style.display="none";//none隐藏图片
document.all.title21.innerHTML="我是大标题"//标题
document.all.detail21.innerHTML="详情描述"//描述
function phone21(){window.open("tel:13527759662"//长号
);}
function dh21(){window.open("tel:689662"//短号
);}
document.all.remark21.innerHTML="备注"//备注


//---服务 22
document.getElementById("id22").style.display="none";//none隐藏
document.getElementById("img22").style.display="none";//none隐藏图片
document.all.title22.innerHTML="我是大标题"//标题
document.all.detail22.innerHTML="详情描述"//描述
function phone22(){window.open("tel:13527759662"//长号
);}
function dh22(){window.open("tel:689662"//短号
);}
document.all.remark22.innerHTML=""//备注


//---服务 23
document.getElementById("id23").style.display="none";//none隐藏
document.getElementById("img23").style.display="none";//none隐藏图片
document.all.title23.innerHTML="我是大标题"//标题
document.all.detail23.innerHTML="详情描述"//描述
function phone23(){window.open("tel:13527759662"//长号
);}
function dh23(){window.open("tel:689662"//短号
);}
document.all.remark23.innerHTML=""//备注


//---服务 24
document.getElementById("id24").style.display="none";//none隐藏
document.getElementById("img24").style.display="none";//none隐藏图片
document.all.title24.innerHTML="我是大标题"//标题
document.all.detail24.innerHTML="详情描述"//描述
function phone24(){window.open("tel:13527759662"//长号
);}
function dh24(){window.open("tel:689662"//短号
);}
document.all.remark24.innerHTML=""//备注


//---服务 25
document.getElementById("id25").style.display="none";//none隐藏
document.getElementById("img25").style.display="none";//none隐藏图片
document.all.title25.innerHTML="我是大标题"//标题
document.all.detail25.innerHTML="详情描述"//描述
function phone25(){window.open("tel:13527759662"//长号
);}
function dh25(){window.open("tel:689662"//短号
);}
document.all.remark25.innerHTML=""//备注


//---服务 26
document.getElementById("id26").style.display="none";//none隐藏
document.getElementById("img26").style.display="none";//none隐藏图片
document.all.title26.innerHTML="我是大标题"//标题
document.all.detail26.innerHTML="详情描述"//描述
function phone26(){window.open("tel:13527759662"//长号
);}
function dh26(){window.open("tel:689662"//短号
);}
document.all.remark26.innerHTML=""//备注


//---服务 27
document.getElementById("id27").style.display="none";//none隐藏
document.getElementById("img27").style.display="none";//none隐藏图片
document.all.title27.innerHTML="我是大标题"//标题
document.all.detail27.innerHTML="详情描述"//描述
function phone27(){window.open("tel:13527759662"//长号
);}
function dh27(){window.open("tel:689662"//短号
);}
document.all.remark27.innerHTML=""//备注


//---服务 28
document.getElementById("id28").style.display="none";//none隐藏
document.getElementById("img28").style.display="none";//none隐藏图片
document.all.title28.innerHTML="我是大标题"//标题
document.all.detail28.innerHTML="详情描述"//描述
function phone28(){window.open("tel:13527759662"//长号
);}
function dh28(){window.open("tel:689662"//短号
);}
document.all.remark28.innerHTML=""//备注


//---服务 29
document.getElementById("id29").style.display="none";//none隐藏
document.getElementById("img29").style.display="none";//none隐藏图片
document.all.title29.innerHTML="我是大标题"//标题
document.all.detail29.innerHTML="详情描述"//描述
function phone29(){window.open("tel:13527759662"//长号
);}
function dh29(){window.open("tel:689662"//短号
);}
document.all.remark29.innerHTML=""//备注


//---服务 30
document.getElementById("id30").style.display="none";//none隐藏
document.getElementById("img30").style.display="none";//none隐藏图片
document.all.title30.innerHTML="我是大标题"//标题
document.all.detail30.innerHTML="详情描述"//描述
function phone30(){window.open("tel:13527759662"//长号
);}
function dh30(){window.open("tel:689662"//短号
);}
document.all.remark30.innerHTML=""//备注