//文字1
document.getElementById("hword1").style.display="";//none隐藏
document.all.w1.innerHTML="尊敬的客户，您好！您已成功办理“1706124_校园手机宽带暑期特惠活动-赠送30元话费”,感谢您的支持。【中国移动】"//内容
document.all.wfr1.innerHTML="暑期宽带费用陆续开始返还，你收到短信了吗？"//来源


	//图1
	document.getElementById("hpic1").style.display="";//none隐藏
	document.all.pfr1.innerHTML="学校后勤查大功率声势浩大，多处挂起横幅"//来源


//文字2
document.getElementById("hword2").style.display="none";//none隐藏
document.all.w2.innerHTML=""//内容
document.all.wfr2.innerHTML="来自群聊或者朋友圈"//来源


	//图2
	document.getElementById("hpic2").style.display="";//none隐藏
	document.all.pfr2.innerHTML="校门口排队乘车长龙 - 来自群聊"//来源


//文字3
document.getElementById("hword3").style.display="none";//none隐藏
document.all.w3.innerHTML=""//内容
document.all.wfr3.innerHTML="来自群聊或者朋友圈"//来源


	//图3
	document.getElementById("hpic3").style.display="none";//none隐藏
	document.all.pfr3.innerHTML="来自群聊"//来源



//视频1
document.getElementById("mv1").style.display="none";//none隐藏
document.all.mfr1.innerHTML="来自群聊"//来源



//视频2
document.getElementById("mv2").style.display="";//none隐藏
document.all.mfr2.innerHTML="视频来自群聊"//来源