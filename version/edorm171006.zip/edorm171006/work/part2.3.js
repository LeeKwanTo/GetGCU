
//  --  Part 2.3  --

//  比赛1
document.getElementById("bs1").style.display="";//none隐藏
document.getElementById("ibs1").style.display="";

document.all.bs1title.innerHTML="广东省首届图书馆杯“4.23世界读书日”主题海报创意大赛"//标题
document.all.bs1detail.innerHTML="征稿时间：2017年9月28日-10月27日"//描述
document.all.bs1fr.innerHTML="华广读协"//来源
function Lbs1(){
window.open("http://mp.weixin.qq.com/s/_7QEDpMXyWb06w5Bt3EbMw"//链接
);}
document.getElementById("bs1g").style.display="none";//不盖章none
document.getElementById("ibs1g").style.display="none";



//  比赛2
document.getElementById("bs2").style.display="";//none隐藏
document.getElementById("ibs2").style.display="";

document.all.bs2title.innerHTML="2017腾讯线上模拟炒股大赛"//标题
document.all.bs2detail.innerHTML="9月29日-12月25日 报名与比赛"//描述
document.all.bs2fr.innerHTML="华工广院金融理财协会"//来源
function Lbs2(){
window.open("http://mp.weixin.qq.com/s/JAK6IHWO58GBDCY9qsq0rQ"//链接
);}
document.getElementById("bs2g").style.display="none";//不盖章none
document.getElementById("ibs2g").style.display="none";



// 比赛3
document.getElementById("bs3").style.display="none";//none隐藏
document.getElementById("ibs3").style.display="none";

document.all.bs3title.innerHTML="我是标题"//标题
document.all.bs3detail.innerHTML="这是描述"//描述
document.all.bs3fr.innerHTML="公众号名称"//来源
function Lbs3(){
window.open("这是链接"//链接
);}
document.getElementById("bs3g").style.display="none";//不能盖章none
document.getElementById("ibs3g").style.display="none";



// 比赛4
document.getElementById("bs4").style.display="none";//none隐藏
document.getElementById("ibs4").style.display="none";

document.all.bs4title.innerHTML="我是标题"//标题
document.all.bs4detail.innerHTML="这是描述"//描述
document.all.bs4fr.innerHTML="公众号名称"//来源
function Lbs4(){
window.open("这是链接"//链接
);}
document.getElementById("bs4g").style.display="none";//不能盖章none
document.getElementById("ibs4g").style.display="none";



// 比赛5
document.getElementById("bs5").style.display="none";//none隐藏
document.getElementById("ibs5").style.display="none";

document.all.bs5title.innerHTML="我是标题"//标题
document.all.bs5detail.innerHTML="这是描述"//描述
document.all.bs5fr.innerHTML="公众号名称"//来源
function Lbs5(){
window.open("这是链接"//链接
);}
document.getElementById("bs5g").style.display="none";//不盖章none
document.getElementById("ibs5g").style.display="none";



// 比赛6
document.getElementById("bs6").style.display="none";//none隐藏
document.getElementById("ibs6").style.display="none";

document.all.bs6title.innerHTML="我是标题"//标题
document.all.bs6detail.innerHTML="这是描述"//描述
document.all.bs6fr.innerHTML="公众号名称"//来源
function Lbs6(){
window.open("这是链接"//链接
);}
document.getElementById("bs6g").style.display="none";//不盖章none
document.getElementById("ibs6g").style.display="none";